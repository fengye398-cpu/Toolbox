local visible = false

function toggle_osc()
    visible = not visible
    if visible then
        mp.commandv("script-message", "osc-visibility", "always", "no-osd")
        mp.osd_message("OSC 已显示")
    else
        mp.commandv("script-message", "osc-visibility", "never", "no-osd")
        mp.osd_message("OSC 已隐藏")
    end
end

mp.add_key_binding(nil, "toggle-osc", toggle_osc)
