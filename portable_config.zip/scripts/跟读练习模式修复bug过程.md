# 短间隔字幕无限循环问题总结

## 问题描述

当字幕文件中存在0ms或极短间隔（<0.3秒）的连续字幕时，sub-pause.lua脚本会出现无限循环，无法正常跳转到下一字幕。

### 问题表现

**测试文件**: `S01E01 - 副本.srt`
- 字幕2: 14.82-15.89
- 字幕3: 15.89-19.09 (0ms间隔)
- 字幕4: 19.09-20.42 (0ms间隔)

**现象**: 字幕3循环2次后应跳到字幕4，但实际上字幕3和字幕4之间无限循环，无法继续播放。

### 日志特征

```
[时间] handle_tick: loop detected, count=3, loop_count=2, pause_mode=0
[时间] handle_tick: AB-loop cleared, advancing to next subtitle
[时间] handle_sub_change: new subtitle detected, start=19.09, end=20.42
[时间] handle_sub_change: AB-loop set, A=19.19, B=20.42
[时间] handle_sub_change: new subtitle detected, start=15.89, end=19.09  # 跳回字幕3
[时间] handle_sub_change: detected backward jump (14.82 -> 15.89)
```

## 根本原因分析

### 1. AB循环机制与字幕边界冲突

当字幕3结束时间(19.09)等于字幕4开始时间(19.09)时：
- AB循环设置: A=19.09, B=20.42
- 当播放到B点时，mpv跳回A点(19.09)
- 但19.09是字幕3和字幕4的共同边界
- mpv的字幕检测可能将19.09识别为字幕3而非字幕4

### 2. 视频文件 vs 音频文件差异

- **视频文件**: 基于帧的播放，seek操作帧精确，字幕时间对齐帧边界
- **音频文件**: 基于采样的连续播放，seek可能有时间漂移和精度问题
- 短间隔字幕在音频文件中更容易触发此问题

### 3. mpv字幕检测振荡

观察到的模式：
1. 清除AB循环并跳到下一字幕
2. mpv检测到字幕4并设置AB循环
3. 1秒后mpv又检测到字幕3
4. 设置字幕3的AB循环
5. 循环往复

这表明mpv的`sub-end`属性在字幕3和字幕4之间振荡。

## 尝试过的解决方案

### 方案1: 跳过短间隔字幕的位置校正 ✅ 部分有效

**代码位置**: `handle_sub_change` 第376-384行

```lua
if prev_sub_end then
    local gap = (sub_start + sub_delay) - prev_sub_end
    if gap < 0.3 then
        should_skip_correction = true
        debug_log("short gap, skipping position correction")
    end
end
```

**效果**: 避免了短间隔字幕的seek操作混乱，但未解决根本问题。

### 方案2: 检测并修复向后跳转 ✅ 部分有效

**代码位置**: `handle_sub_change` 第343-351行

```lua
if last_sub_start and sub_start < last_sub_start then
    local backward_gap = last_sub_start - sub_start
    if backward_gap < 2.0 then
        debug_log("detected backward jump, seeking forward")
        mp.commandv("seek", last_sub_start + sub_delay, "absolute+exact")
        return
    end
end
```

**效果**: 能检测到向后跳转并尝试修复，但修复后仍会再次跳回。

### 方案3: 调整AB循环A点位置 ❌ 无效

**代码位置**: `handle_sub_change` 第388-398行

```lua
-- 对于短间隔字幕，将A点向前调整
if prev_sub_end and (loop_a - prev_sub_end) < 0.3 then
    loop_a = loop_a + 0.1  -- 从0.01改为0.1
end
```

**尝试**:
- 调整量0.01秒: 无效
- 调整量0.1秒: 无效

**原因**: 调整A点无法解决mpv字幕检测振荡的根本问题。

### 方案4: Seek到字幕结束位置之后 ❌ 无效

**代码位置**: `handle_tick` 第302-309行

```lua
local sub_end = mp.get_property_number("sub-end")
if sub_end then
    mp.commandv("seek", sub_end + 0.05, "absolute+exact")
end
```

**问题**:
- Seek到15.89+0.05=15.94，落在字幕3范围内(15.89-19.09)
- 导致字幕3被重新检测并设置AB循环

### 方案5: 添加冷却期 ❌ 引入新问题

**代码位置**: 已移除

```lua
ab_loop_cooldown_until = mp.get_time() + 0.5
if current_time < ab_loop_cooldown_until then
    return  -- 跳过AB循环设置
end
```

**问题**:
- 冷却期导致跳过紧邻的下一字幕
- 例如：字幕3→跳过字幕4→设置字幕5的AB循环
- 然后字幕4被检测到，形成新的循环

### 方案6: 使用sub-seek 1 ❌ 无效

**代码位置**: `handle_tick` 第302-309行（当前方案）

```lua
should_seek_to_start = true
mp.command("no-osd sub-seek 1")
```

**问题**: 即使明确跳到下一字幕，mpv仍会在1秒后检测到前一字幕。

## 当前状态

**最新代码**:
- 使用`sub-seek 1`跳转下一字幕
- 短间隔字幕跳过位置校正
- 向后跳转检测和修复
- A点调整0.1秒（间隔<0.3秒时）

**问题依然存在**: 字幕3-4无限循环

## 可能的解决方向

### 方向1: 禁用短间隔字幕的AB循环

对于间隔<0.1秒的字幕，不使用AB循环机制，改用其他方式实现循环：
- 手动计时并在字幕结束时seek回开始位置
- 使用mpv的`--loop-file`配合时间范围限制

**优点**: 避开AB循环机制的边界问题
**缺点**: 需要重写循环逻辑，可能影响现有功能

### 方向2: 延迟设置AB循环

在检测到新字幕后，延迟0.5-1秒再设置AB循环：
```lua
mp.add_timeout(0.5, function()
    -- 再次确认当前字幕，然后设置AB循环
end)
```

**优点**: 给mpv足够时间稳定字幕检测
**缺点**: 可能影响用户体验，循环开始有延迟

### 方向3: 监听不同的属性

不监听`sub-end`，改为监听`sub-text`或其他属性：
```lua
mp.observe_property("sub-text", "string", handle_sub_change)
```

**优点**: 可能避开`sub-end`属性的振荡问题
**缺点**: 需要重写大量逻辑

### 方向4: 合并短间隔字幕

预处理字幕文件，将间隔<0.1秒的连续字幕合并：
- 字幕3 (15.89-19.09) + 字幕4 (19.09-20.42) → 合并为 (15.89-20.42)

**优点**: 从源头解决问题
**缺点**: 需要修改字幕文件，不适合通用场景

### 方向5: 使用mpv的Lua API限制

研究mpv是否提供更底层的API来控制AB循环行为：
- 禁用自动循环，手动控制跳转
- 使用`--ab-loop-a`和`--ab-loop-b`命令行参数而非属性

## 相关文件

- **脚本**: `D:\Tools\mpv\portable_config\scripts\sub-pause.lua`
- **配置**: `D:\Tools\mpv\portable_config\script-opts\sub_pause.conf`
- **日志**: `D:\Tools\mpv\portable_config\sub-pause-debug.log`
- **测试字幕**: `D:\桌面\000000\S01E01 - 副本.srt`

## 测试用例

### 正常工作的情况

- 字幕间隔 > 0.3秒: ✅ 正常
- 视频文件 + 大间隔字幕: ✅ 正常
- 音频文件 + 90ms间隔: ✅ 已修复（通过方案1+2）

### 仍有问题的情况

- 视频/音频文件 + 0ms间隔: ❌ 无限循环
- 连续多个0ms间隔字幕: ❌ 无限循环

## 调试建议

1. **启用详细日志**: 已在代码中添加`debug_log`
2. **监控mpv属性变化**:
   ```lua
   mp.observe_property("sub-start", "number", function(_, val)
       print("sub-start changed:", val)
   end)
   ```
3. **测试不同的seek偏移量**: 尝试0.05, 0.1, 0.2秒
4. **测试不同的A点调整量**: 尝试0.15, 0.2秒

## 参考资料

- mpv Lua API文档: https://mpv.io/manual/master/#lua-scripting
- AB-loop机制: https://mpv.io/manual/master/#command-interface-ab-loop
- 字幕处理: https://mpv.io/manual/master/#options-sub

---

**最后更新**: 2025-12-13
**状态**: 未解决，待后续修复
