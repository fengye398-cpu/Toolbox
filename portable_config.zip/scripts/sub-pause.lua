-- feel free to modify and/or redistribute as long as you give credit to the original creator; © 2022 Ben Kerman

local cfg = {
	default_start = false,
	default_end = false,
	end_delta = 0.1,
	hide_while_playing = false,
	unpause_time = 0,
	unpause_override = "SPACE",
	replay_prev = true,
	loop_count = 0,  -- 循环次数：0=无限循环，>=1=循环指定次数后自动下一字幕
	pause_mode = 0,  -- 停顿模式：0=连续循环，1=重复间停顿，2=连续后停顿
	pause_duration_type = 1,  -- 停顿时长类型：1=句子倍数，2=固定秒数
	pause_multiplier = 1.5,  -- 倍数模式：停顿时长倍数
	pause_seconds = 2.5  -- 固定模式：停顿秒数
}
require("mp.options").read_options(cfg)

local active = false
local pause_at_start = cfg.default_start
local pause_at_end = cfg.default_end
local skip_next = false
local pause_at = 0
local current_loop_count = 0  -- 当前已循环次数
local ab_loop_cooldown_until = 0  -- AB循环冷却期结束时间
local loop_overlay = mp.create_osd_overlay("ass-events")
local in_practice_pause = false  -- 是否在跟读练习停顿中
local practice_pause_timer = nil  -- 停顿定时器
local skip_next_loop_pause = false  -- Mode1: 跳过下一次循环的停顿检测
local end_pause_timer = nil  -- Mode1: 字幕结束前停顿的定时器

-- 手动循环控制（用于音频文件的短间隔字幕）
local use_manual_loop = false  -- 是否使用手动循环模式
local manual_loop_sub_start = nil  -- 手动循环的字幕开始时间
local manual_loop_sub_end = nil  -- 手动循环的字幕结束时间
local manual_loop_sub_delay = nil  -- 手动循环的字幕延迟

-- 调试日志
local log_file = nil
local log_path = mp.command_native({"expand-path", "~~/sub-pause-debug.log"})

function debug_log(msg)
	if not log_file then
		log_file = io.open(log_path, "w")
		if log_file then
			log_file:write(string.format("=== Sub-Pause Debug Log ===\n"))
			log_file:write(string.format("Time: %s\n", os.date("%Y-%m-%d %H:%M:%S")))
			log_file:write(string.format("Config: loop_count=%d, pause_mode=%d\n\n", cfg.loop_count, cfg.pause_mode))
		end
	end
	if log_file then
		log_file:write(string.format("[%s] %s\n", os.date("%H:%M:%S"), msg))
		log_file:flush()
	end
end

function update_loop_display()
	if pause_at_end and current_loop_count > 0 then
		local text
		if cfg.loop_count > 0 then
			text = string.format("循环 %d/%d", current_loop_count, cfg.loop_count)
		else
			text = string.format("已循环 %d 次", current_loop_count)
		end
		mp.osd_message(text, 1)
	end
end

-- Mode1: 在字幕结束前设置停顿
function schedule_end_pause()
	if end_pause_timer then
		end_pause_timer:kill()
	end

	local sub_start = mp.get_property_number("sub-start")
	local sub_end = mp.get_property_number("sub-end")
	local sub_delay = mp.get_property_number("sub-delay")
	local time_pos = mp.get_property_number("time-pos")

	if not sub_start or not sub_end or not sub_delay then
		debug_log("schedule_end_pause: missing sub properties")
		return
	end

	local sub_duration = sub_end - sub_start
	local time_until_end

	if time_pos then
		-- 使用当前播放位置计算
		local sub_end_time = sub_end + sub_delay
		time_until_end = sub_end_time - time_pos - 0.05  -- 提前0.05秒触发
	else
		-- 无法获取 time_pos，使用字幕时长作为备选
		time_until_end = sub_duration - 0.05
		debug_log("schedule_end_pause: time_pos unavailable, using sub_duration")
	end

	if time_until_end <= 0 then
		debug_log(string.format("schedule_end_pause: already at end, time_until_end=%.2f", time_until_end))
		return
	end

	debug_log(string.format("schedule_end_pause: will pause in %.2fs", time_until_end))

	end_pause_timer = mp.add_timeout(time_until_end, function()
		debug_log("schedule_end_pause: timer triggered, pausing")
		in_practice_pause = true
		local pause_duration = calculate_pause_duration()
		mp.set_property_bool("pause", true)
		mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)

		if practice_pause_timer then
			practice_pause_timer:kill()
		end

		practice_pause_timer = mp.add_timeout(pause_duration, function()
			in_practice_pause = false
			debug_log("schedule_end_pause: pause ended, seeking to start")
			local sub_start = mp.get_property_number("sub-start")
			local sub_delay = mp.get_property_number("sub-delay")
			if sub_start and sub_delay then
				mp.commandv("seek", sub_start + sub_delay, "absolute+exact")
			end
			mp.set_property_bool("pause", false)
		end)
	end)
end

-- 计算停顿时长
function calculate_pause_duration()
	if cfg.pause_duration_type == 2 then
		-- 固定秒数模式
		return cfg.pause_seconds
	else
		-- 句子倍数模式
		local sub_start = mp.get_property_number("sub-start")
		local sub_end = mp.get_property_number("sub-end")
		if sub_start and sub_end then
			local sub_duration = sub_end - sub_start
			return sub_duration * cfg.pause_multiplier
		end
		return cfg.pause_seconds  -- 降级到固定秒数
	end
end

-- 执行跟读练习停顿
function do_practice_pause()
	if in_practice_pause then
		debug_log("do_practice_pause: already in pause, skipping")
		return
	end
	in_practice_pause = true

	local pause_duration = calculate_pause_duration()
	debug_log(string.format("do_practice_pause: starting pause for %.2fs", pause_duration))
	mp.set_property_bool("pause", true)
	mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)

	-- 清除旧定时器
	if practice_pause_timer then
		practice_pause_timer:kill()
	end

	-- 设置定时器自动恢复
	practice_pause_timer = mp.add_timeout(pause_duration, function()
		in_practice_pause = false
		-- 重新定位到字幕开始位置并恢复播放
		local sub_start = mp.get_property_number("sub-start")
		local sub_delay = mp.get_property_number("sub-delay")
		debug_log(string.format("do_practice_pause: pause ended, seeking to %.2f", sub_start and (sub_start + sub_delay) or 0))
		if sub_start and sub_delay then
			mp.commandv("seek", sub_start + sub_delay, "absolute+exact")
		end
		mp.set_property_bool("pause", false)
		debug_log("do_practice_pause: playback resumed")
	end)
end

function set_visibility(state)
	mp.set_property_bool("sub-visibility", state)
	-- force OSD/sub redraw
	mp.osd_message(" ", 0.001)
end

function handle_pause(_, paused)
	if cfg.hide_while_playing and not paused then
		set_visibility(false)
		mp.unobserve_property(handle_pause)
	end
end

function pause()
	if skip_next then skip_next = false
	else
		mp.set_property_bool("pause", true)
		if cfg.hide_while_playing then
			set_visibility(true)
		end
		if cfg.unpause_time > 0 then
			local timer = mp.add_timeout(cfg.unpause_time, function()
				replay_sub()
				mp.remove_key_binding("unpause-override")
			end)
			mp.add_forced_key_binding(cfg.unpause_override, "unpause-override", function()
				timer:kill()
				mp.remove_key_binding("unpause-override")
			end)
		end
		mp.observe_property("pause", "bool", handle_pause)
	end
end

local last_loop_time = 0

-- 手动循环监控函数（用于音频文件的短间隔字幕）
function handle_manual_loop(_, time_pos)
	if time_pos == nil then return end
	if in_practice_pause then return end
	if not use_manual_loop then return end

	local sub_end_time = manual_loop_sub_end + manual_loop_sub_delay

	-- 到达字幕结束时间
	if time_pos >= sub_end_time - 0.05 then
		current_loop_count = current_loop_count + 1
		debug_log(string.format("handle_manual_loop: loop detected, count=%d, loop_count=%d, pause_mode=%d", current_loop_count, cfg.loop_count, cfg.pause_mode))

		-- 模式1：重复间停顿（每次循环后停顿）
		if cfg.pause_mode == 1 and cfg.loop_count > 0 then
			if current_loop_count > cfg.loop_count + 1 then
				-- 达到循环次数，跳转下一字幕
				debug_log(string.format("handle_manual_loop Mode1: count(%d) > loop_count+1(%d), next sub", current_loop_count, cfg.loop_count + 1))
				current_loop_count = 1
				use_manual_loop = false
				mp.unobserve_property(handle_manual_loop)
				should_seek_to_start = true
				mp.command("no-osd sub-seek 1")
			else
				-- 每次循环后都停顿
				local display_count = current_loop_count
				local is_last_pause = (current_loop_count == cfg.loop_count + 1)
				debug_log(string.format("handle_manual_loop Mode1: count(%d), display(%d/%d), pausing, last=%s", current_loop_count, display_count, cfg.loop_count, tostring(is_last_pause)))
				in_practice_pause = true
				local pause_duration = calculate_pause_duration()
				mp.set_property_bool("pause", true)
				mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)
				if practice_pause_timer then
					practice_pause_timer:kill()
				end
				practice_pause_timer = mp.add_timeout(pause_duration, function()
					in_practice_pause = false
					if is_last_pause then
						-- 最后一次停顿后，跳转下一字幕
						debug_log("handle_manual_loop Mode1: last pause ended, jumping to next")
						current_loop_count = 1
						use_manual_loop = false
						mp.unobserve_property(handle_manual_loop)
						should_seek_to_start = true
						mp.set_property_bool("pause", false)
						mp.command("no-osd sub-seek 1")
					else
						-- 普通停顿后，seek回字幕开始
						debug_log(string.format("handle_manual_loop Mode1: pause ended, seeking back to start %.2f", manual_loop_sub_start + manual_loop_sub_delay))
						mp.commandv("seek", manual_loop_sub_start + manual_loop_sub_delay, "absolute+exact")
						mp.set_property_bool("pause", false)
						mp.osd_message(string.format("循环 %d/%d", display_count, cfg.loop_count), 1)
					end
				end)
			end
		-- 模式2：连续后停顿（完成所有循环后停顿）
		elseif cfg.pause_mode == 2 and cfg.loop_count > 0 then
			if current_loop_count <= cfg.loop_count then
				-- 未达到循环次数，继续循环
				debug_log(string.format("handle_manual_loop Mode2: seeking back to start %.2f", manual_loop_sub_start + manual_loop_sub_delay))
				mp.commandv("seek", manual_loop_sub_start + manual_loop_sub_delay, "absolute+exact")
				update_loop_display()
			else
				-- 达到循环次数，停顿后跳下一字幕
				debug_log(string.format("handle_manual_loop Mode2: count(%d) > loop_count(%d), pausing then next sub", current_loop_count, cfg.loop_count))
				current_loop_count = 1
				update_loop_display()
				in_practice_pause = true
				local pause_duration = calculate_pause_duration()
				mp.set_property_bool("pause", true)
				mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)
				if practice_pause_timer then
					practice_pause_timer:kill()
				end
				practice_pause_timer = mp.add_timeout(pause_duration, function()
					in_practice_pause = false
					use_manual_loop = false
					mp.unobserve_property(handle_manual_loop)
					should_seek_to_start = true
					debug_log("handle_manual_loop Mode2: pause ended, seeking to next subtitle")
					mp.command("no-osd sub-seek 1")
					mp.set_property_bool("pause", false)
				end)
			end
		-- 模式3：单次播放（播放1次后跳到下一字幕）
		elseif cfg.pause_mode == 3 then
			if current_loop_count > 1 then
				-- 已播放1次，跳到下一字幕
				debug_log(string.format("handle_manual_loop Mode3: count(%d) > 1, next sub", current_loop_count))
				current_loop_count = 1
				use_manual_loop = false
				mp.unobserve_property(handle_manual_loop)
				should_seek_to_start = true
				mp.command("no-osd sub-seek 1")
			end
		-- 模式0：连续循环（原有逻辑）
		else
			if cfg.loop_count > 0 and current_loop_count > cfg.loop_count then
				-- 达到循环次数，跳到下一字幕
				debug_log("handle_manual_loop Mode0: loop count reached, advancing to next subtitle")
				current_loop_count = 1
				use_manual_loop = false
				mp.unobserve_property(handle_manual_loop)
				should_seek_to_start = true
				mp.command("no-osd sub-seek 1")
			else
				-- 继续循环，seek回字幕开始
				debug_log(string.format("handle_manual_loop Mode0: seeking back to start %.2f", manual_loop_sub_start + manual_loop_sub_delay))
				mp.commandv("seek", manual_loop_sub_start + manual_loop_sub_delay, "absolute+exact")
				update_loop_display()
			end
		end
	end
end

function handle_tick(_, time_pos)
	if time_pos == nil then return end

	-- 停顿期间不检测循环
	if in_practice_pause then return end

	local loop_a = mp.get_property_number("ab-loop-a")

	if loop_a and math.abs(time_pos - loop_a) < 0.1 then
		local current_time = mp.get_time()
		local time_since_last = current_time - last_loop_time

		-- 防止重复计数：至少间隔 0.2 秒
		if time_since_last > 0.2 then
			current_loop_count = current_loop_count + 1
			last_loop_time = current_time
			debug_log(string.format("handle_tick: loop detected, count=%d, loop_count=%d, pause_mode=%d", current_loop_count, cfg.loop_count, cfg.pause_mode))

			-- 模式1：重复间停顿（每次循环后停顿）
			if cfg.pause_mode == 1 and cfg.loop_count > 0 then
				if current_loop_count > cfg.loop_count + 1 then
					-- 达到循环次数，跳转下一字幕
					debug_log(string.format("Mode1: count(%d) > loop_count+1(%d), next sub", current_loop_count, cfg.loop_count + 1))
					current_loop_count = 1
					mp.set_property("ab-loop-a", "no")
					mp.set_property("ab-loop-b", "no")
					should_seek_to_start = true
					debug_log("Mode1: seeking to next subtitle")
					mp.command("no-osd sub-seek 1")
				else
					-- 每次循环后都停顿
					local display_count = current_loop_count  -- count=2显示2/3, count=3显示3/3
					local is_last_pause = (current_loop_count == cfg.loop_count + 1)
					debug_log(string.format("Mode1: count(%d), display(%d/%d), pausing, last=%s", current_loop_count, display_count, cfg.loop_count, tostring(is_last_pause)))
					in_practice_pause = true
					local pause_duration = calculate_pause_duration()
					mp.set_property_bool("pause", true)
					mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)
					if practice_pause_timer then
						practice_pause_timer:kill()
					end
					practice_pause_timer = mp.add_timeout(pause_duration, function()
						in_practice_pause = false
						if is_last_pause then
							-- 最后一次停顿后，跳转下一字幕
							debug_log("Mode1: last pause ended, jumping to next")
							current_loop_count = 1
							mp.set_property("ab-loop-a", "no")
							mp.set_property("ab-loop-b", "no")
							should_seek_to_start = true
							mp.set_property_bool("pause", false)  -- 恢复播放
							mp.command("no-osd sub-seek 1")
						else
							-- 普通停顿后，恢复播放并显示循环计数
							debug_log("Mode1: pause ended, resuming (no seek)")
							last_loop_time = mp.get_time()  -- 更新时间，防止立即触发循环检测
							mp.set_property_bool("pause", false)
							-- 显示下一次播放的循环计数（闭包捕获 display_count）
							mp.osd_message(string.format("循环 %d/%d", display_count, cfg.loop_count), 1)
						end
					end)
				end
			-- 模式2：连续后停顿（完成所有循环后停顿）
			elseif cfg.pause_mode == 2 and cfg.loop_count > 0 then
				if current_loop_count <= cfg.loop_count then
					-- 未达到循环次数，继续循环
					update_loop_display()
				elseif current_loop_count > cfg.loop_count then
					-- 达到循环次数，停顿后跳下一字幕
					debug_log(string.format("Mode2: count(%d) > loop_count(%d), pausing then next sub", current_loop_count, cfg.loop_count))
					current_loop_count = 1
					mp.set_property("ab-loop-a", "no")
					mp.set_property("ab-loop-b", "no")
					debug_log("Mode2: AB-loop cleared")
					update_loop_display()
					-- 停顿后自动跳下一字幕
					in_practice_pause = true
					local pause_duration = calculate_pause_duration()
					mp.set_property_bool("pause", true)
					mp.osd_message(string.format("停顿 %.1f秒", pause_duration), pause_duration)
					if practice_pause_timer then
						practice_pause_timer:kill()
					end
					practice_pause_timer = mp.add_timeout(pause_duration, function()
						in_practice_pause = false
						should_seek_to_start = true
						debug_log("Mode2: pause ended, seeking to next subtitle")
						mp.command("no-osd sub-seek 1")
						mp.set_property_bool("pause", false)
					end)
				end
			-- 模式3：单次播放（播放1次后跳到下一字幕）
			elseif cfg.pause_mode == 3 then
				if current_loop_count > 1 then
					-- 已播放1次，跳到下一字幕
					debug_log(string.format("Mode3: count(%d) > 1, next sub", current_loop_count))
					current_loop_count = 1
					mp.set_property("ab-loop-a", "no")
					mp.set_property("ab-loop-b", "no")
					should_seek_to_start = true
					mp.command("no-osd sub-seek 1")
				end
			-- 模式0：连续循环（原有逻辑）
			else
				if cfg.loop_count > 0 and current_loop_count > cfg.loop_count then
					current_loop_count = 1
					mp.set_property("ab-loop-a", "no")
					mp.set_property("ab-loop-b", "no")
					debug_log("handle_tick: AB-loop cleared, advancing to next subtitle")
					-- 使用sub-seek明确跳到下一字幕
					should_seek_to_start = true
					mp.command("no-osd sub-seek 1")
				else
					update_loop_display()
				end
			end
		end
	end
end

local last_sub_start = nil
local prev_sub_end = nil

local should_seek_to_start = false

function handle_sub_change(_, sub_end)
	--if no subtitle track loaded then we don't need to try to pause
	if mp.get_property_number('sid', -1) == -1 then
		return
	end

	mp.unobserve_property(handle_tick)

	if sub_end ~= nil then
		if pause_at_start then pause() end

		if pause_at_end then
			local sub_start = mp.get_property_number("sub-start")
			local sub_delay = mp.get_property_number("sub-delay")
			local current_pos = mp.get_property_number("time-pos")

			if sub_start ~= nil then
				-- 检测短间隔回退（从后面的字幕跳回前面）- 移到最前面
				if last_sub_start and sub_start < last_sub_start then
					local backward_gap = last_sub_start - sub_start
					if backward_gap < 2.0 then  -- 回退距离<2秒，说明陷入循环
						debug_log(string.format("handle_sub_change: detected backward jump (%.2f -> %.2f), clearing AB-loop and forcing next subtitle", last_sub_start, sub_start))
						mp.set_property("ab-loop-a", "no")
						mp.set_property("ab-loop-b", "no")
						should_seek_to_start = true
						mp.command("no-osd sub-seek 1")
						return
					end
				end

				local is_new_sub = (sub_start ~= last_sub_start)

				-- 只在真正切换字幕时重置计数（sub_start 变化）
				if is_new_sub then
						current_loop_count = 1  -- 从1开始，表示第1次循环
					last_loop_time = 0
					last_sub_start = sub_start
					debug_log(string.format("handle_sub_change: new subtitle detected, start=%.2f, end=%.2f", sub_start, sub_end))

					-- 模式1：显示初始循环计数
					if cfg.pause_mode == 1 and cfg.loop_count > 0 then
						mp.osd_message(string.format("循环 1/%d", cfg.loop_count), 1)
					end

					-- 如果是手动跳转字幕，立即 seek 到字幕开始位置
					if should_seek_to_start then
							mp.commandv("seek", sub_start + sub_delay, "absolute+exact")
						should_seek_to_start = false
						debug_log("handle_sub_change: seeking to start (manual jump)")
					-- 如果当前位置已超过字幕开始点，立即 seek 到开始点避免触发额外循环
					elseif current_pos and current_pos > sub_start + sub_delay then
						-- 检查与前一字幕的间隔
						local should_skip_correction = false
						if prev_sub_end then
							local gap = (sub_start + sub_delay) - prev_sub_end
							if gap < 0.3 then
								-- 短间隔字幕，跳过位置校正避免seek混乱
								should_skip_correction = true
								debug_log(string.format("handle_sub_change: short gap (%.2fs), skipping position correction", gap))
							end
						end

						if not should_skip_correction then
							mp.commandv("seek", sub_start + sub_delay, "absolute+exact")
							debug_log("handle_sub_change: seeking to start (position correction)")
						end
					end
				end

				-- 如果已经在手动循环模式中，且不是新字幕，直接返回
				if use_manual_loop and not is_new_sub then
					return
				end

				-- 检测是否是音频文件且短间隔字幕
				local video_codec = mp.get_property("video-codec")
				local is_audio_only = (video_codec == nil or video_codec == "")
				local gap = prev_sub_end and ((sub_start + sub_delay) - prev_sub_end) or 1.0

				-- 音频文件 + 短间隔字幕：使用手动循环
				if is_audio_only and prev_sub_end and gap >= 0 and gap < 0.1 then
					debug_log(string.format("handle_sub_change: audio file with short gap (%.2fs), using manual loop", gap))
					use_manual_loop = true
					manual_loop_sub_start = sub_start
					manual_loop_sub_end = sub_end
					manual_loop_sub_delay = sub_delay

					-- 监听时间位置以手动控制循环
					mp.unobserve_property(handle_tick)
					mp.observe_property("time-pos", "number", handle_manual_loop)

					if is_new_sub then
						update_loop_display()
					end
				else
					-- 正常使用AB循环
					use_manual_loop = false
					mp.unobserve_property(handle_manual_loop)

					-- 设置 A-B 循环点
					local loop_a = sub_start + sub_delay
					local loop_b = sub_end + sub_delay
					-- 对于短间隔字幕，将A点向前调整更多，避免AB循环跳回时落在边界上
					if prev_sub_end and (loop_a - prev_sub_end) < 0.3 then
						loop_a = loop_a + 0.1
						debug_log(string.format("handle_sub_change: adjusting A point for short gap subtitle (%.2f -> %.2f)", sub_start + sub_delay, loop_a))
					end
					mp.set_property_number("ab-loop-a", loop_a)
					mp.set_property_number("ab-loop-b", loop_b)
					debug_log(string.format("handle_sub_change: AB-loop set, A=%.2f, B=%.2f", loop_a, loop_b))

					-- 重置循环时间戳，避免第一次检测时间间隔过大
					if is_new_sub then
						-- 设置为未来时间，防止AB循环设置时的跳转被误判为循环
						local sub_duration = sub_end - sub_start
						last_loop_time = mp.get_time() + math.max(0.3, sub_duration * 0.5)
						-- 显示初始循环次数（1/1 或 1/2）
						update_loop_display()
					end

					-- 监听时间位置以检测循环
					mp.observe_property("time-pos", "number", handle_tick)
				end
				-- 更新 prev_sub_end 供下次边界检查使用
				if is_new_sub then prev_sub_end = sub_end end
			end
		else
			-- 清除 A-B 循环
			mp.set_property("ab-loop-a", "no")
			mp.set_property("ab-loop-b", "no")
			debug_log("handle_sub_change: AB-loop cleared (pause_at_end=false)")
		end
	end
end

function replay_sub()
	-- prevent pause if pausing at start is enabled
	if pause_at_start then skip_next = true end

	local sub_start = mp.get_property_number("sub-start")
	if sub_start ~= nil then
		mp.commandv("seek", sub_start + mp.get_property_number("sub-delay"), "absolute+exact")
		mp.set_property_bool("pause", false)
	elseif cfg.replay_prev then
		mp.command("no-osd sub-seek -1")
		mp.set_property_bool("pause", false)
	end
end


function display_state()
        local msg
        if pause_at_end then
                msg = "开启循环"
        else
                msg = "解除循环"
        end
        mp.osd_message(msg)
  end

local saved_visibility = true

function toggle()
	if active then
		if not pause_at_start and not pause_at_end then
			pause_at = 0
			skip_next = false
			mp.unobserve_property(handle_sub_change)
			mp.unobserve_property(handle_tick)
			active = false
			if cfg.hide_while_playing then
				set_visibility(saved_visibility)
			end
			mp.unobserve_property(handle_pause)
		end
	else
		if cfg.hide_while_playing then
			saved_visibility = mp.get_property_bool("sub-visibility")
			set_visibility(false)
		end
		mp.observe_property("sub-end", "number", handle_sub_change)
		active = true
	end
	display_state()
end

mp.add_key_binding(nil, "toggle-start", function()
	pause_at_start = not pause_at_start
	toggle()
end)

mp.add_key_binding(nil, "toggle-end", function()
	pause_at_end = not pause_at_end
	if not pause_at_end then
		current_loop_count = 1
		mp.set_property("ab-loop-a", "no")
		mp.set_property("ab-loop-b", "no")
	end
	toggle()
end)

mp.add_key_binding("Alt+r", "skip-next", function() skip_next = true end)

mp.add_key_binding("Ctrl+r", "replay", function() replay_sub() end)

if pause_at_start or pause_at_end then
	toggle()
end

-- ========== 自定义功能：字幕跳转+循环播放 ==========
-- 功能说明：
-- 1. seek_prev_and_loop: 跳转到上一字幕并开启循环播放
-- 2. seek_next_and_loop: 跳转到下一字幕并开启循环播放
-- 3. 如果循环未开启(pause_at_end=false)，会自动开启
-- 4. 配合 handle_tick 中的 replay_sub() 实现无缝循环
--
-- 使用方法：
-- 在 input.conf 中绑定按键，例如：
-- e script-binding sub_pause/seek-prev-loop
-- d script-binding sub_pause/seek-next-loop
-- \ script-binding sub_pause/toggle-end

-- 跳转到上一字幕并循环播放
function seek_prev_and_loop()
	-- 如果循环未开启，自动开启
	if not pause_at_end then
		pause_at_end = true
		if not active then
			toggle()
		end
	end
	-- 标记需要 seek 到字幕开始位置
	should_seek_to_start = true
	-- 跳转到上一字幕
	mp.command("no-osd sub-seek -1")
	-- 确保播放状态
	mp.set_property_bool("pause", false)
end

-- 跳转到下一字幕并循环播放
function seek_next_and_loop()
	-- 如果循环未开启，自动开启
	if not pause_at_end then
		pause_at_end = true
		if not active then
			toggle()
		end
	end
	-- 标记需要 seek 到字幕开始位置
	should_seek_to_start = true
	-- 跳转到下一字幕
	mp.command("no-osd sub-seek 1")
	-- 确保播放状态
	mp.set_property_bool("pause", false)
end

-- 注册按键绑定（nil表示不设置默认按键，需要在input.conf中手动绑定）
mp.add_key_binding(nil, "seek-prev-loop", seek_prev_and_loop)
mp.add_key_binding(nil, "seek-next-loop", seek_next_and_loop)

-- ========== 跟读练习模式切换 ==========
-- 功能说明：
-- 1. toggle_pause_mode: 循环切换停顿模式（0→1→2→0）
-- 2. 显示当前模式的OSD提示
-- 3. 模式0：连续循环（无停顿）
-- 4. 模式1：重复间停顿（每次播放后停顿）
-- 5. 模式2：连续后停顿（连续播放N次后停顿）

-- 获取模式名称
function get_pause_mode_name()
	if cfg.pause_mode == 0 then
		return "连续循环"
	elseif cfg.pause_mode == 1 then
		return "重复间停顿"
	elseif cfg.pause_mode == 2 then
		return "连续后停顿"
	elseif cfg.pause_mode == 3 then
		return "单次播放"
	end
	return "未知模式"
end

-- 切换停顿模式
function toggle_pause_mode()
	cfg.pause_mode = (cfg.pause_mode + 1) % 4
	local mode_name = get_pause_mode_name()
	local duration_info = ""
	if cfg.pause_mode > 0 and cfg.pause_mode < 3 then
		if cfg.pause_duration_type == 1 then
			duration_info = string.format(" (%.1f倍句长)", cfg.pause_multiplier)
		else
			duration_info = string.format(" (%.1f秒)", cfg.pause_seconds)
		end
	end
	mp.osd_message(string.format("停顿模式: %s%s", mode_name, duration_info), 2)
end

-- 绑定快捷键（默认无按键，需在input.conf中配置）
mp.add_key_binding(nil, "toggle-pause-mode", toggle_pause_mode)
