# mpvacious 快捷键迁移说明

## 重要变更

从本版本开始，mpvacious 不再在脚本中硬编码快捷键，改为使用 `script-binding` 方式，所有快捷键需要在 `input.conf` 中配置。

## 为什么要改？

1. **避免快捷键冲突**：用户可以在 input.conf 中看到所有快捷键，轻松管理冲突
2. **灵活性更高**：用户可以自由修改、禁用或重新绑定任何快捷键
3. **符合 mpv 最佳实践**：这是 mpv 官方推荐的脚本快捷键管理方式

## 如何配置

### 1. 快捷键已添加到 input.conf

所有 mpvacious 快捷键已经添加到 `portable_config/input.conf` 文件中，默认快捷键与之前版本保持一致。

### 2. 快捷键列表

```conf
# 核心功能
a           script-binding mpvacious/menu-open                  # 打开菜单
Ctrl+n      script-binding mpvacious/export-note                # 创建卡片

# 笔记更新
Ctrl+b      script-binding mpvacious/update-selected-note       # 更新选中笔记
Ctrl+B      script-binding mpvacious/overwrite-selected-note    # 覆盖选中笔记
Ctrl+m      script-binding mpvacious/update-last-note           # 更新最后笔记
Ctrl+M      script-binding mpvacious/overwrite-last-note        # 覆盖最后笔记

# 快速制卡
g           script-binding mpvacious/quick-card-menu-open       # 快速制卡菜单
Alt+g       script-binding mpvacious/quick-card-sel-menu-open   # 快速制卡选择

# 字幕跳转（默认禁用，避免冲突）
#H           script-binding mpvacious/sub-seek-back              # 上一句字幕
#L           script-binding mpvacious/sub-seek-forward           # 下一句字幕
#Alt+h       script-binding mpvacious/sub-seek-back-pause        # 上一句并暂停
#Alt+l       script-binding mpvacious/sub-seek-forward-pause     # 下一句并暂停

# 字幕播放控制（默认禁用，避免冲突）
#Ctrl+h      script-binding mpvacious/sub-rewind                 # 重播当前字幕
#Ctrl+H      script-binding mpvacious/sub-replay                 # 播放到字幕结束
#Ctrl+L      script-binding mpvacious/sub-play-up-to-next        # 播放到下一句结束

# 次字幕
Ctrl+v      script-binding mpvacious/secondary-sid-toggle       # 切换次字幕
Ctrl+k      script-binding mpvacious/secondary-sid-prev         # 上一个次字幕轨
Ctrl+j      script-binding mpvacious/secondary-sid-next         # 下一个次字幕轨

# 其他
Ctrl+t      script-binding mpvacious/autocopy-toggle            # 切换自动复制
Ctrl+g      script-binding mpvacious/animated-snapshot-toggle   # 切换动画截图
```

### 3. 自定义快捷键

#### 修改快捷键
在 input.conf 中修改左侧的按键：
```conf
# 将 a 改为 Ctrl+a
Ctrl+a      script-binding mpvacious/menu-open
```

#### 禁用快捷键
注释掉整行或改为 ignore：
```conf
# 方法1：注释掉
#Ctrl+n      script-binding mpvacious/export-note

# 方法2：改为 ignore
Ctrl+n      ignore
```

#### 添加多个快捷键
同一个命令可以绑定多个快捷键：
```conf
a           script-binding mpvacious/menu-open
Ctrl+a      script-binding mpvacious/menu-open
```

## 可用命令列表

所有可用的 mpvacious 命令：

| 命令名称 | 功能说明 |
|---------|---------|
| `menu-open` | 打开 mpvacious 菜单 |
| `export-note` | 从当前字幕创建卡片 |
| `update-selected-note` | 更新选中的笔记（追加） |
| `overwrite-selected-note` | 更新选中的笔记（覆盖） |
| `update-last-note` | 更新最后一张笔记（追加） |
| `overwrite-last-note` | 更新最后一张笔记（覆盖） |
| `quick-card-menu-open` | 打开快速制卡菜单 |
| `quick-card-sel-menu-open` | 打开快速制卡选择菜单 |
| `sub-seek-back` | 跳转到上一句字幕 |
| `sub-seek-forward` | 跳转到下一句字幕 |
| `sub-seek-back-pause` | 跳转到上一句字幕并暂停 |
| `sub-seek-forward-pause` | 跳转到下一句字幕并暂停 |
| `sub-rewind` | 重播当前字幕 |
| `sub-replay` | 播放到当前字幕结束 |
| `sub-play-up-to-next` | 播放到下一句字幕结束 |
| `secondary-sid-toggle` | 切换次字幕可见性 |
| `secondary-sid-prev` | 选择上一个次字幕轨道 |
| `secondary-sid-next` | 选择下一个次字幕轨道 |
| `autocopy-toggle` | 切换自动复制字幕 |
| `animated-snapshot-toggle` | 切换动画截图 |

## 故障排查

### 快捷键不工作

1. 检查 input.conf 中是否有该快捷键配置
2. 检查是否有其他脚本占用了相同的快捷键
3. 重启 mpv 使配置生效

### 如何查看当前绑定的快捷键

在 mpv 中按 `~` 打开控制台，输入：
```
show-text ${input-bindings}
```

### 恢复默认配置

如果修改出错，可以从 `PROJECT_STRUCTURE.md` 或本文档中复制默认配置。

## 迁移检查清单

- [x] 修改 subs2srs.lua，移除所有 `add_key_binding`
- [x] 使用 `register_script_message` 注册命令
- [x] 在 input.conf 中添加所有快捷键配置
- [x] 标注有冲突的快捷键（H/L/Ctrl+h 等）
- [x] 提供完整的命令列表文档

## 相关文档

- `PROJECT_STRUCTURE.md` - 项目结构说明
- `VIDEO_EXPORT_CHANGELOG.md` - 视频导出功能修改记录
- `input.conf` - 快捷键配置文件
