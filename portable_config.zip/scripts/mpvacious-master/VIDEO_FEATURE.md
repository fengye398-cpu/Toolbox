# 视频片段功能实现文档

## 概述

在现有的"截图+音频"基础上，添加"视频片段"功能，实现"截图+音频+视频"三合一制卡。

## 实现方案

### 1. 配置文件修改

**文件：** `script-opts/subs2srs.conf`

添加以下配置项：

```conf
##
## 视频设置
##

# 视频字段名称，留空则不创建视频文件
video_field=Video

# 视频格式
# mp4 - 兼容性最好，推荐用于 AnkiMobile
# webm - 文件更小，但移动端支持有限
video_format=mp4

# 视频编码器
# libx264 - H.264 编码，兼容性好
# libx265 - H.265 编码，文件更小但编码慢
video_codec=libx264

# 视频质量 (CRF 值)
# 范围 0-51，越小质量越高，文件越大
# 推荐值：18-28
# 18 = 高质量，24 = 默认，28 = 较低质量
video_quality=24

# 视频分辨率
# -2 表示保持宽高比自动计算
# 建议限制高度以控制文件大小
video_width=-2
video_height=480

# 视频模板
# 类似 image_template 和 audio_template
video_template=<video controls src="%s"></video>
```

### 2. 代码修改

#### 2.1 encoder.lua 添加视频编码器

**文件：** `encoder/encoder.lua`

在 `create_job` 函数中添加 `videoclip` 类型处理（参考 `audioclip` 实现）：

```lua
-- 在 create_job 函数中添加
elseif job_type == 'videoclip' then
    encoder_args = make_videoclip_args(config, sub, padding)
    extension = '.' .. config.video_format
```

添加 `make_videoclip_args` 函数：

```lua
local make_videoclip_args = function(config, sub, padding)
    local args = {
        '-ss', tostring(math.max(0, sub['start'] - (padding or 0))),
        '-to', tostring(sub['end'] + (padding or 0)),
        '-c:v', config.video_codec,
        '-crf', tostring(config.video_quality),
        '-c:a', 'aac',
        '-b:a', '128k',
    }

    -- 添加分辨率参数
    if config.video_width and config.video_height then
        table.insert(args, '-vf')
        table.insert(args, string.format('scale=%d:%d', config.video_width, config.video_height))
    end

    return args
end
```

在模块导出中添加：

```lua
return {
    -- ... 现有代码 ...
    video = {
        create_job = function(sub, padding)
            return create_job('videoclip', sub, padding)
        end,
    },
}
```

#### 2.2 subs2srs.lua 添加配置和逻辑

**文件：** `subs2srs.lua`

在配置部分添加：

```lua
-- 在 config 表中添加
video_field = "",
video_format = "mp4",
video_codec = "libx264",
video_quality = 24,
video_width = -2,
video_height = 480,
video_template = '<video controls src="%s"></video>',
```

修改 `construct_note_fields` 函数签名：

```lua
local function construct_note_fields(sub_text, secondary_text, snapshot_filename, audio_filename, video_filename)
    -- ... 现有代码 ...

    -- 在函数末尾添加
    if not h.is_empty(config.video_field) and not h.is_empty(video_filename) then
        ret[config.video_field] = string.format(config.video_template, video_filename)
    end

    return ret
end
```

修改 `export_to_anki` 函数：

```lua
local function export_to_anki(gui)
    -- ... 现有代码 ...

    local snapshot = encoder.snapshot.create_job(sub)
    local audio = encoder.audio.create_job(sub, audio_padding())
    local video = encoder.video.create_job(sub, audio_padding())  -- 新增

    snapshot.run_async()
    audio.run_async()
    video.run_async()  -- 新增

    local note_fields = construct_note_fields(
        sub['text'],
        sub['secondary'],
        snapshot.filename,
        audio.filename,
        video.filename  -- 新增
    )

    -- ... 其余代码 ...
end
```

修改 `update_sentence` 函数（类似修改）：

```lua
local function update_sentence(note_ids, overwrite)
    -- ... 现有代码 ...

    local snapshot = encoder.snapshot.create_job(sub)
    local audio = encoder.audio.create_job(sub, audio_padding())
    local video = encoder.video.create_job(sub, audio_padding())  -- 新增
    local new_data = construct_note_fields(
        sub['text'],
        sub['secondary'],
        snapshot.filename,
        audio.filename,
        video.filename  -- 新增
    )

    -- 修改 countdown 从 2 改为 3
    local create_files_countdown = dec_counter.new(3).on_finish(h.as_callback(change_fields, note_ids, new_data, overwrite))

    snapshot.on_finish(create_files_countdown.decrease).run_async()
    audio.on_finish(create_files_countdown.decrease).run_async()
    video.on_finish(create_files_countdown.decrease).run_async()  -- 新增
end
```

### 3. 配置文件示例

**文件：** `script-opts/subs2srs.conf`

```conf
# 启用视频功能
video_field=Video

# 使用 mp4 格式（兼容性最好）
video_format=mp4
video_codec=libx264

# 中等质量（平衡文件大小和质量）
video_quality=24

# 限制高度为 480p
video_width=-2
video_height=480

# 视频模板
video_template=<video controls src="%s"></video>
```

## 注意事项

### 1. 文件大小

- 视频文件通常 1-10MB（取决于时长和质量）
- 音频文件通常 50-200KB
- 图片文件通常 100-500KB

**建议：**
- 限制视频分辨率（480p 或 720p）
- 使用合理的 CRF 值（23-28）
- 定期清理不需要的卡片

### 2. AnkiWeb 同步限制

- AnkiWeb 对单个媒体文件有大小限制
- 大量视频会导致同步缓慢或失败

**建议：**
- 使用自建 Anki 同步服务器
- 或者只在桌面端使用，不同步到移动端

### 3. 移动端兼容性

**AnkiMobile (iOS):**
- 支持 mp4 (H.264)
- 支持 webm（iOS 17.4+）

**AnkiDroid:**
- 支持 mp4 (H.264)
- 支持 webm

**推荐格式：** mp4 + H.264（兼容性最好）

### 4. 性能影响

- 视频编码比音频慢 5-10 倍
- 同时编码 3 个文件会增加 CPU 负载
- 建议在性能较好的电脑上使用

### 5. 禁用视频功能

如果不需要视频，只需将 `video_field` 设为空：

```conf
video_field=
```

## 测试步骤

### 1. 基础测试

1. 修改配置文件，启用视频功能
2. 在 mpv 中播放视频
3. 选择字幕时间范围
4. 按快捷键制卡
5. 检查 Anki 媒体文件夹是否生成视频文件
6. 在 Anki 中查看卡片，确认视频可以播放

### 2. 格式测试

测试不同格式和质量：

```conf
# 测试 1: mp4 高质量
video_format=mp4
video_quality=18

# 测试 2: mp4 中等质量
video_format=mp4
video_quality=23

# 测试 3: mp4 低质量
video_format=mp4
video_quality=28

# 测试 4: webm 格式
video_format=webm
video_codec=libvpx-vp9
video_quality=30
```

### 3. 分辨率测试

```conf
# 测试 1: 480p
video_height=480

# 测试 2: 720p
video_height=720

# 测试 3: 原始分辨率
video_height=-1
```

### 4. 兼容性测试

1. 在 Anki Desktop 中播放视频
2. 同步到 AnkiWeb
3. 在 AnkiMobile/AnkiDroid 中测试播放

### 5. 性能测试

1. 测量编码时间
2. 检查文件大小
3. 监控 CPU 使用率

## 故障排查

### 视频文件未生成

1. 检查 `video_field` 是否配置
2. 检查 FFmpeg 是否安装
3. 查看 mpv 控制台错误信息

### 视频无法播放

1. 检查视频格式是否支持
2. 尝试使用 mp4 + H.264
3. 检查 Anki 版本（建议 2.1.50+）

### 文件太大

1. 降低分辨率（480p 或更低）
2. 增加 CRF 值（25-28）
3. 缩短视频时长

### 编码太慢

1. 降低分辨率
2. 使用 libx264（比 libx265 快）
3. 考虑只在需要时启用视频

## 预期文件大小参考

**5 秒视频片段：**
- 480p, CRF 23: ~500KB - 1MB
- 720p, CRF 23: ~1MB - 2MB
- 1080p, CRF 23: ~2MB - 4MB

**10 秒视频片段：**
- 480p, CRF 23: ~1MB - 2MB
- 720p, CRF 23: ~2MB - 4MB
- 1080p, CRF 23: ~4MB - 8MB

## 总结

视频功能是一个强大的补充，可以提供更丰富的上下文信息。但需要注意文件大小和同步问题。建议：

1. 默认禁用，按需启用
2. 使用 480p 分辨率
3. 使用 mp4 + H.264 格式
4. 考虑自建同步服务器
5. 定期清理不需要的卡片

---

**文档版本：** 1.0
**创建日期：** 2025-12-06
**作者：** Claude Code
