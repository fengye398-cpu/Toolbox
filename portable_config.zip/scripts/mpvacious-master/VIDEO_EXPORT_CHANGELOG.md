# 视频导出功能修改记录

## 修改日期
2025-12-07

## 功能说明
在原有的"音频+图片"导出基础上，新增"视频+音频+图片"导出功能。

## 修改文件清单

### 1. cfg_mgr.lua
**位置**: 第82-141行

**修改内容**:
- `set_video_format()` 函数中添加视频格式配置（第82-90行）
- 新增 `check_video_settings()` 函数验证视频参数（第126-133行）
- `validate_config()` 中调用 `check_video_settings()`（第140行）

### 2. encoder/encoder.lua
**位置**: 第302-786行

**修改内容**:
- 新增 `ffmpeg.make_videoclip_args()` 函数（第302-320行）
  - 参数：source_path, output_path, start_timestamp, end_timestamp
  - 使用 lanczos 缩放算法
  - 视频编码：libx264/libx265，CRF 可配置
  - 音频编码：aac
  - 像素格式：yuv420p

- 新增 `make_video_filename()` 函数（第695-697行）
- 新增 `create_videoclip()` 函数（第699-712行）
  - **注意**：直接使用 `ffmpeg.make_videoclip_args()`，不支持 mpv encoder

- `create_job()` 中添加 'videoclip' 分支（第746-750行）
- 导出 `video.create_job()` 接口（第782-786行）

### 3. subs2srs.lua
**位置**: 第112-553行

**修改内容**:
- 添加视频默认配置（第112-118行）:
  ```lua
  video_format = "mp4"
  video_codec = "libx264"
  video_crf = 24
  video_preset = "veryfast"
  video_width = cfg_mgr.preserve_aspect_ratio
  video_height = 480
  ```

- 添加 `video_field` 和 `video_template` 配置（第159-160行）
- `construct_note_fields()` 接受 video_filename 参数（第314行）
- `export_to_anki()` 创建视频任务（第450行）
- `update_notes()` 创建视频任务并动态调整计数器（第546-549行）
- `join_fields()` 添加 video_field（第379行）

### 4. subs2srs.conf
**位置**: 第186-210行

**新增配置项**:
```conf
## 视频设置
video_field=                    # 视频字段名称（为空则不创建视频）
video_format=mp4                # mp4 或 webm
video_codec=libx264             # libx264 或 libx265
video_crf=24                    # 0-51，越小质量越高
video_preset=veryfast           # 编码速度预设
video_width=-1                  # -1 保持原始分辨率，-2 保持宽高比
video_height=-1                 # 同上
video_template=[sound:%s]       # 视频模板
```

## 使用方法

1. 在 `subs2srs.conf` 中设置 `video_field=Video`（或你的 Anki 模板中的视频字段名）
2. 根据需要调整视频参数（CRF、preset、分辨率等）
3. 制卡时会自动导出视频、音频、图片三个文件

## 技术要点

1. **仅支持 FFmpeg**：视频编码只使用 FFmpeg，不支持 mpv encoder
2. **动态计数器**：`update_notes()` 中根据 `video_field` 是否为空动态设置文件计数（2或3）
3. **保留音频**：视频中包含音频，但仍单独导出音频文件
4. **参数参考**：视频编码参数参考 toanki.py（libx264, CRF, preset, yuv420p, aac）

## 默认行为

- `video_field` 默认为空，不影响现有用户
- 启用后与音频、图片并行导出
- 视频文件名格式与音频、图片一致

## 故障排查

如果脚本无法启动：
1. 检查 `scripts/mpvacious-master/main.lua` 是否存在
2. 确保所有依赖模块（osd_styler.lua, helpers.lua 等）在同一目录
3. 检查 mpv 日志中的 Lua 错误信息
