# mpvacious 项目结构文档

## 项目概述
mpvacious 是一个 mpv 脚本，用于从视频中提取字幕、音频、图片（和视频）并导出到 Anki 制作学习卡片。

## 目录结构

```
mpvacious-master/
├── main.lua                    # 入口文件，加载 subs2srs.lua
├── subs2srs.lua               # 核心脚本（926行）
├── cfg_mgr.lua                # 配置管理（245行）
├── ankiconnect.lua            # AnkiConnect API 通信
├── helpers.lua                # 工具函数库
├── menu.lua                   # OSD 菜单系统
├── osd_styler.lua             # OSD 样式
│
├── encoder/                   # 媒体编码模块
│   ├── encoder.lua           # 编码器核心（788行）
│   └── codec_support.lua     # 编解码器支持检测
│
├── subtitles/                 # 字幕处理模块
│   ├── observer.lua          # 字幕观察器
│   ├── secondary_sid.lua     # 次字幕管理
│   ├── subtitle.lua          # 字幕对象
│   └── sub_list.lua          # 字幕列表
│
├── utils/                     # 工具模块
│   ├── base64.lua            # Base64 编码
│   ├── dec_counter.lua       # 递减计数器（异步任务同步）
│   ├── filename_factory.lua  # 文件名生成
│   ├── forvo.lua             # Forvo 发音支持
│   ├── pause_timer.lua       # 暂停计时器
│   ├── play_control.lua      # 播放控制
│   ├── switch.lua            # 开关工具
│   └── timings.lua           # 时间处理
│
├── platform/                  # 平台适配
│   ├── init.lua              # 平台检测
│   ├── nix.lua               # Linux/Unix 平台
│   └── win.lua               # Windows 平台
│
├── howto/                     # 使用教程
│   ├── add_dialog.md
│   ├── create_card.md
│   ├── create_quick_card.md
│   ├── flatpak.md
│   ├── goldendict.md
│   ├── update_selected_card.md
│   └── yomichan.md
│
├── .github/                   # GitHub 配置
│   ├── ISSUE_TEMPLATE/
│   └── RELEASE/
│       ├── release-boilerplate.md
│       └── subs2srs.conf     # 示例配置文件
│
├── README.md                  # 项目说明
├── LICENSE                    # GPL-3.0 许可证
├── VIDEO_FEATURE.md          # 视频功能设计文档
├── VIDEO_EXPORT_CHANGELOG.md # 视频导出修改记录
└── CUSTOM_MODIFICATIONS.md   # 自定义修改说明
```

## 核心文件说明

### 1. main.lua (入口)
```lua
require('subs2srs')
```
- 简单的入口文件
- mpv 自动加载 scripts 目录下的 .lua 文件

### 2. subs2srs.lua (核心逻辑)
**主要功能**:
- 配置管理和初始化
- 字幕采集和处理
- 制卡流程控制
- 菜单系统集成
- 快捷键绑定

**关键函数**:
- `export_to_anki()` - 导出到 Anki（第435-465行）
- `update_notes()` - 更新已有笔记（第519-557行）
- `construct_note_fields()` - 构建笔记字段（第314-358行）

### 3. cfg_mgr.lua (配置管理)
**主要功能**:
- 读取配置文件（subs2srs.conf）
- 配置验证和默认值设置
- 多配置文件支持
- 格式转换（音频/视频/图片）

**关键函数**:
- `init()` - 初始化配置
- `validate_config()` - 验证配置
- `reload_from_disk()` - 重新加载配置

### 4. encoder/encoder.lua (编码器)
**主要功能**:
- FFmpeg 和 mpv 两种编码器支持
- 音频片段提取
- 静态/动画截图
- 视频片段提取（新增）

**编码器对象**:
- `ffmpeg` - FFmpeg 编码器（第94-384行）
- `mpv` - mpv 编码器（第389-561行）

**导出接口**:
```lua
encoder.snapshot.create_job(sub)
encoder.audio.create_job(sub, padding)
encoder.video.create_job(sub)  -- 新增
```

### 5. ankiconnect.lua (Anki 通信)
**主要功能**:
- AnkiConnect API 封装
- 笔记增删改查
- 媒体文件上传
- 牌组和模板管理

**关键函数**:
- `add_note()` - 添加笔记
- `append_media()` - 更新笔记媒体
- `get_media_dir_path()` - 获取 Anki 媒体目录

### 6. helpers.lua (工具函数)
**主要功能**:
- 字符串处理
- 文件操作
- 时间格式化
- 子进程调用
- 通知显示

### 7. subtitles/observer.lua (字幕观察器)
**主要功能**:
- 监听字幕变化
- 字幕时间轴管理
- 字幕文本采集
- 手动时间设置

## 工作流程

### 制卡流程
```
1. 用户按快捷键（Ctrl+n 或菜单中的 n）
   ↓
2. subs2srs.lua: export_to_anki()
   ↓
3. 采集字幕文本和时间
   ↓
4. 并行创建三个任务：
   - encoder.snapshot.create_job() → 图片
   - encoder.audio.create_job() → 音频
   - encoder.video.create_job() → 视频（如果启用）
   ↓
5. 异步执行 FFmpeg 编码
   ↓
6. construct_note_fields() 构建字段
   ↓
7. ankiconnect.add_note() 发送到 Anki
```

### 更新笔记流程
```
1. 用户选择要更新的笔记
   ↓
2. subs2srs.lua: update_notes()
   ↓
3. 创建媒体文件（同上）
   ↓
4. dec_counter 等待所有文件完成
   ↓
5. change_fields() 更新笔记字段
   ↓
6. ankiconnect.append_media() 上传到 Anki
```

## 配置文件

### subs2srs.conf 位置
```
~/.config/mpv/script-opts/subs2srs.conf  (Linux/Mac)
%APPDATA%/mpv/script-opts/subs2srs.conf  (Windows)
portable_config/script-opts/subs2srs.conf (便携版)
```

### 主要配置项
```conf
# Anki 设置
deck_name=Learning
model_name=Japanese sentences
sentence_field=SentKanji
audio_field=SentAudio
image_field=Image
video_field=Video  # 新增

# 编码器选择
use_ffmpeg=yes

# 音频设置
audio_format=opus
audio_bitrate=18k

# 图片设置
snapshot_format=avif
snapshot_quality=15

# 视频设置（新增）
video_format=mp4
video_codec=libx264
video_crf=24
video_preset=veryfast
```

## 快捷键

### 默认快捷键
- `a` - 打开 mpvacious 菜单
- `Ctrl+n` - 从当前字幕创建卡片
- `Ctrl+c` - 复制字幕到剪贴板
- `Ctrl+h` - 设置字幕开始时间
- `Ctrl+Shift+h` - 设置字幕结束时间
- `Ctrl+g` - 切换动画截图
- `Ctrl+t` - 切换次字幕可见性

### 菜单快捷键
- `s` - 设置开始时间
- `e` - 设置结束时间
- `c` - 设置到当前字幕
- `r` - 重置时间
- `n` - 创建笔记
- `g` - 创建笔记（打开 Anki 浏览器）
- `m` - 更新最后一张笔记
- `b` - 更新选中的笔记

## 依赖关系

### 外部依赖
- mpv >= 0.32.0
- AnkiConnect 插件
- FFmpeg（如果 use_ffmpeg=yes）
- curl（用于 AnkiConnect 通信）

### 模块依赖图
```
main.lua
  └─ subs2srs.lua
      ├─ cfg_mgr.lua
      ├─ encoder/encoder.lua
      │   ├─ helpers.lua
      │   ├─ utils/filename_factory.lua
      │   └─ encoder/codec_support.lua
      ├─ ankiconnect.lua
      ├─ menu.lua
      │   └─ osd_styler.lua
      ├─ subtitles/observer.lua
      │   ├─ subtitles/subtitle.lua
      │   └─ subtitles/sub_list.lua
      ├─ subtitles/secondary_sid.lua
      ├─ platform/init.lua
      ├─ utils/forvo.lua
      ├─ utils/dec_counter.lua
      ├─ utils/play_control.lua
      └─ utils/switch.lua
```

## 扩展点

### 添加新的媒体类型
1. 在 `encoder/encoder.lua` 添加编码函数
2. 在 `create_job()` 添加新的 job_type
3. 在 `subs2srs.lua` 的 `export_to_anki()` 和 `update_notes()` 中创建任务
4. 在 `construct_note_fields()` 添加字段处理
5. 在配置文件添加相关选项

### 添加新的字幕处理
1. 修改 `subtitles/observer.lua`
2. 在 `subs2srs.lua` 的 `prepare_for_exporting()` 添加处理逻辑

### 添加新的平台支持
1. 在 `platform/` 目录添加新的平台文件
2. 在 `platform/init.lua` 添加检测逻辑

## 调试

### 启用调试日志
```bash
mpv --msg-level=all=trace video.mkv
```

### 常见问题
1. **脚本不加载**: 检查 main.lua 是否在 scripts 目录
2. **找不到模块**: 检查 package.path 设置
3. **AnkiConnect 连接失败**: 检查 Anki 是否运行，AnkiConnect 是否安装
4. **FFmpeg 编码失败**: 检查 FFmpeg 是否在 PATH 中

## 许可证
GPL-3.0 License

## 相关文档
- README.md - 项目说明和使用指南
- VIDEO_FEATURE.md - 视频功能设计文档
- VIDEO_EXPORT_CHANGELOG.md - 视频导出修改记录
- CUSTOM_MODIFICATIONS.md - 自定义修改说明
