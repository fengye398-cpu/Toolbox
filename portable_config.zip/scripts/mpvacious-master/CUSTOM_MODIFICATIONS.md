# mpvacious 自定义修改记录

修改日期：2025-12-06

## 1. 图片分辨率设置

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\cfg_mgr.lua`

**修改位置：** 第 15 行

```lua
# 原始值
local max_side_px = 1920

# 修改为
local max_side_px = 999999
```

**目的：** 允许使用视频原始分辨率截图

---

## 2. 时间戳格式

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\helpers.lua`

**修改位置：** 第 210 行

```lua
# 原始代码
local ret = string.format("%02dm%02ds%03dms", parts.m, parts.s, parts.ms)
if parts.h > 0 then
    ret = string.format('%dh%s', parts.h, ret)
end
return ret

# 修改为
return string.format("%d.%02d.%02d.%03d", parts.h, parts.m, parts.s, parts.ms)
```

**格式变化：** `03m30s780ms` → `0.03.30.780`

---

## 3. 文件名特殊字符处理

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\helpers.lua`

**修改位置：** 第 181-186 行

```lua
# 原始代码
this.remove_special_characters = function(str)
    return str:gsub('[%c%p%s]', ''):gsub('　', '')
end

# 修改为
this.remove_special_characters = function(str)
    -- Replace spaces and dots with underscores
    str = str:gsub('[%s%.]', '_'):gsub('　', '_')
    -- Remove all special characters except letters, numbers, underscores, and hyphens
    str = str:gsub('[^%w_%-]', '')
    return str
end
```

**效果：** 空格和点号替换为下划线，只保留字母、数字、下划线、连字符

---

## 4. 文件名生成逻辑

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\utils\filename_factory.lua`

### 4.1 简化文件名处理（第 50-59 行）

```lua
# 原始代码
local make_media_filename = function()
    filename = mp.get_property("filename")
    filename = h.remove_extension(filename)
    local operations = {
        h.remove_filename_text_in_parentheses,
        h.remove_text_in_brackets,
        h.remove_special_characters
    }
    for _, f in ipairs(operations) do
        local temp_filename = f(filename)
        if temp_filename ~= "" then
            filename = temp_filename
        end
    end
end

# 修改为
local make_media_filename = function()
    filename = mp.get_property("filename")
    filename = h.remove_extension(filename)
    filename = h.remove_special_characters(filename)
    if filename == "" or filename == nil then
        filename = "subs2srs"
    end
end
```

**目的：** 保留所有字母数字内容，避免删除有用信息

### 4.2 文件名空值保护（第 82-88 行）

```lua
# 原始代码
local make_filename = function(...)
    local args = {...}
    local timestamp = #args < 3 and timestamp_static(...) or timestamp_range(...)
    return string.lower(anki_compatible_length(filename, timestamp) .. timestamp)
end

# 修改为
local make_filename = function(...)
    local args = {...}
    local timestamp = #args < 3 and timestamp_static(...) or timestamp_range(...)
    local base_name = (filename and filename ~= "") and filename or "subs2srs"
    return anki_compatible_length(base_name, timestamp) .. timestamp
end
```

**变化：**
1. 移除 `string.lower`（保持原始大小写）
2. 添加空值保护

---

## 5. 图片文件名统一

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\encoder\encoder.lua`

**修改位置：** 第 667 行

```lua
# 原始代码
return filename_factory.make_filename(timestamp, self.config.snapshot_extension)

# 修改为
return filename_factory.make_filename(start_time, end_time, self.config.snapshot_extension)
```

**目的：** 图片和音频使用相同的时间范围格式

---

## 6. 音频比特率模式

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\encoder\encoder.lua`

**修改位置：** 第 344-347 行

```lua
# 原始代码
encoder_args = {
    '-c:a', 'libmp3lame',
    '-compression_level', '0',
    '-abr', '1',
}

# 修改为
encoder_args = {
    '-c:a', 'libmp3lame',
    '-compression_level', '0',
}
```

**效果：** 从 ABR（平均比特率）改为 CBR（恒定比特率）

---

## 7. 音频声道设置

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\encoder\encoder.lua`

**修改位置：** 第 323 行

```lua
# 原始值
'-ac', '1',

# 修改为
'-ac', '2',
```

**效果：** 从单声道改为立体声

---

## 8. 配置文件修改

**文件：** `D:\Tools\mpv\portable_config\script-opts\subs2srs.conf`

### 8.1 禁用 Anki 界面弹出（第 126 行）
```
disable_gui_browse=yes
```

### 8.2 图片尺寸（第 154-155 行）
```
snapshot_width=-1
snapshot_height=-1
```

### 8.3 音频格式（第 209-210 行）
```
#audio_format=opus
audio_format=mp3
```

### 8.4 音频比特率（第 227 行）
```
audio_bitrate=128k
```

### 8.5 禁用音频增益（第 317 行）
```
#ffmpeg_audio_args=-af loudnorm=I=-16:TP=-1.5:LRA=11:dual_mono=true
ffmpeg_audio_args=
```

### 8.6 ID 字段（第 25 行）
```
id_field=Id
```

### 8.7 换行符拆分（第 30 行）
```
split_on_newline=yes
```

---

## 9. ID 字段功能

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\subs2srs.lua`

**修改位置：** 第 159、319-322 行

```lua
# 添加配置（第 159 行）
id_field = "Id", -- Card ID field (filename without extension)

# 添加字段生成逻辑（第 319-322 行）
if not h.is_empty(config.id_field) and not h.is_empty(audio_filename) then
    -- Use audio filename without extension as card ID
    ret[config.id_field] = audio_filename:gsub('%.[^.]+$', '')
end
```

**效果：** 自动填充 ID 字段为文件名（不含扩展名）

---

## 10. 换行符拆分功能

**文件：** `D:\Tools\mpv\portable_config\scripts\mpvacious-master\subs2srs.lua`

**修改位置：** 第 160、209-213、299-308、310-317 行

### 10.1 添加配置（第 160 行）
```lua
split_on_newline = true, -- Split subtitle on first newline when no secondary subtitle loaded
```

### 10.2 保留换行符（第 299-308 行）
```lua
# 原始代码
local function prepare_for_exporting(sub_text)
    if not h.is_empty(sub_text) then
        sub_text = h.trim(sub_text)
        sub_text = h.escape_special_characters(sub_text)
    end
    return sub_text
end

# 修改为
local function prepare_for_exporting(sub_text)
    if not h.is_empty(sub_text) then
        -- Don't use h.trim() as it removes newlines
        sub_text = h.remove_leading_trailing_spaces(sub_text)
        sub_text = h.remove_text_in_parentheses(sub_text)
        sub_text = h.normalize_spaces(sub_text)
        sub_text = h.escape_special_characters(sub_text)
    end
    return sub_text
end
```

### 10.3 OSD 显示处理（第 209-213 行）
```lua
# 原始代码
local function escape_for_osd(str)
    str = h.trim(str)
    str = str:gsub('[%[%]{}]', '')
    return str
end

# 修改为
local function escape_for_osd(str)
    str = h.trim(str)
    str = str:gsub('[%[%]{}]', '')
    str = str:gsub('[\n\r]+', ' ')  -- Remove newlines for OSD display
    return str
end
```

### 10.4 拆分逻辑（第 310-317 行）
```lua
-- Split on newline if enabled and no secondary subtitle loaded
if config.split_on_newline and h.is_empty(secondary_text) and not h.is_empty(sub_text) then
    local first_line, rest = sub_text:match("^([^\n]+)\n(.+)$")
    if first_line and rest then
        sub_text = first_line
        secondary_text = rest:gsub("\n", "<br>")
    end
end
```

**效果：**
- 保留字幕中的换行符
- 当没有加载次字幕时，自动按第一个换行符拆分主字幕
- 第一行 → sentence_field
- 其余行 → secondary_field（多个换行符转换为 `<br>`）
- OSD 显示时移除换行符，避免布局混乱

---

## 最终效果

**文件命名格式：**
- 图片：`S1Ep3_Peppa_Pig_-_Teddys_Day_Out_0.02.24.450-0.02.26.050.webp`
- 音频：`S1Ep3_Peppa_Pig_-_Teddys_Day_Out_0.02.24.450-0.02.26.050.mp3`

**特点：**
- 图片使用原始分辨率
- 文件名统一格式，空格和点号替换为下划线
- 音频 128k CBR 立体声，无增益处理
- 制卡时不弹出 Anki 界面
