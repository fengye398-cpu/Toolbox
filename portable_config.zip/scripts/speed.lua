-- MPV倍速一键切换脚本：z键 ↔ 1.0倍速/原倍速
local control_key = "Z"  -- 快捷键，可自定义
local save_speed = mp.get_property_number("speed", 1.0)  -- 修复：用数字类型获取，指定默认值

-- 核心切换函数
local function speed_toggle(n)
    local current_speed = tonumber(n) or 1.0  -- 容错：防止n为nil/非数字
    if current_speed == 1 then
        mp.set_property("speed", save_speed)
    else
        save_speed = current_speed  -- 简化：直接赋值，无需重复调用API
        mp.set_property("speed", 1)
    end
    -- 格式化显示+屏幕提示
    local show_speed = string.format("%.1f", mp.get_property("speed"))
    mp.osd_message("Speed: " .. show_speed, 1.0)  -- 提示停留1.0秒，更友好
end

-- 绑定快捷键（MPV标准写法）
mp.add_key_binding(control_key, "speed_toggle", function()
    speed_toggle(mp.get_property("speed"))
end)
