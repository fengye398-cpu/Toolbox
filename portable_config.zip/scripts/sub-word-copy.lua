-- 单词复制脚本
local utils = require 'mp.utils'

local words = {}
local current_index = 0
local selection_start = 0
local selection_end = 0
local overlay_id = mp.create_osd_overlay("ass-events")

function split_words(text)
    local result = {}
    for word in text:gmatch("%S+") do
        table.insert(result, word)
    end
    return result
end

function show_words()
    local sub_text = mp.get_property("sub-text")
    if not sub_text or sub_text == "" then
        mp.osd_message("无字幕")
        return
    end

    words = split_words(sub_text)
    if #words == 0 then return end

    current_index = 1
    selection_start = 1
    selection_end = 1
    display_words()
end

function display_words()
    if #words == 0 then return end

    local start_idx = math.min(selection_start, selection_end)
    local end_idx = math.max(selection_start, selection_end)

    local display = ""
    for i, word in ipairs(words) do
        if i >= start_idx and i <= end_idx then
            display = display .. "{\\b1\\c&H00FFFF&}" .. word .. "{\\r} "
        else
            display = display .. word .. " "
        end
    end

    overlay_id.data = display
    overlay_id:update()
end

function next_word()
    if #words == 0 then return end
    current_index = current_index + 1
    if current_index > #words then current_index = 1 end
    selection_start = current_index
    selection_end = current_index
    display_words()
end

function prev_word()
    if #words == 0 then return end
    current_index = current_index - 1
    if current_index < 1 then current_index = #words end
    selection_start = current_index
    selection_end = current_index
    display_words()
end

function extend_next()
    if #words == 0 then return end
    selection_end = selection_end + 1
    if selection_end > #words then selection_end = #words end
    display_words()
end

function extend_prev()
    if #words == 0 then return end
    selection_end = selection_end - 1
    if selection_end < 1 then selection_end = 1 end
    if selection_start == selection_end then
        current_index = selection_start
    end
    display_words()
end

function copy_word()
    if #words == 0 then return end

    local start_idx = math.min(selection_start, selection_end)
    local end_idx = math.max(selection_start, selection_end)

    local selected = {}
    for i = start_idx, end_idx do
        table.insert(selected, words[i])
    end
    local text = table.concat(selected, " ")

    utils.subprocess({
        args = {'powershell', '-Command', 'Set-Clipboard -Value "' .. text .. '"'},
        cancellable = false,
    })

    mp.osd_message("已复制: " .. text)
    overlay_id.data = ""
    overlay_id:update()
    words = {}
    current_index = 0
    selection_start = 0
    selection_end = 0
end

function cancel()
    overlay_id.data = ""
    overlay_id:update()
    words = {}
    current_index = 0
    selection_start = 0
    selection_end = 0
    mp.osd_message("已取消")
end

-- 快捷键绑定（在 input.conf 中配置）
mp.add_key_binding(nil, "show-words", show_words)
mp.add_key_binding(nil, "next-word", next_word, {repeatable=true})
mp.add_key_binding(nil, "prev-word", prev_word, {repeatable=true})
mp.add_key_binding(nil, "extend-next", extend_next, {repeatable=true})
mp.add_key_binding(nil, "extend-prev", extend_prev, {repeatable=true})
mp.add_key_binding(nil, "copy-word", copy_word)
mp.add_key_binding(nil, "cancel-word", cancel)
